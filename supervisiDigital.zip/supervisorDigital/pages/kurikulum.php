<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Buat Jadwal</title>

    <link rel="stylesheet" href="../styles/style.css" />
    <link href="https://fonts.googleapis.com/css2?family=Source+Sans+Pro&display=swap" rel="stylesheet">
  </head>
  <form method="post" enctype="multipart/form-data" action="aksiupload.php">
  <body>
    <header class="container">
      <nav>
        <h4>Supervisi Digital</h4>
        <ul>
          <li><a href="#">Upload Jadwal</a></li>
          <li><a href="jadwal.php">Cek Jadwal</a></li>
          <li><a href="../logout.php">logout</a></li>
        </ul>
      </nav>
    </header>

    <main class="container mt-2">

        <div class="eight columns">
          <div class="row">
            <div class="four columns">
              <label>Hari :</label>
            </div>

            <div class="eight columns">
              <select>
                <option nama="hari" value="senin">Senin</option>
                <option nama="hari" value="selasa">Selasa</option>
                <option nama="hari" value="rabu">Rabu</option>
                <option nama="hari" value="kamis">Kamis</option>
                <option nama="hari" value="jumat">jum'at</option>
                <option nama="hari" value="sabtu">Sabtu</option>
                <option nama="hari" value="minggu">Minggu</option>
              </select>
            </div>

            <div class="twelve columns">
              <label>Upload File Jadwal :</label>
            </div>

            <div class="twelve columns">
              <input type="file" name="berkas">
              <input type="submit" name="tombol" value="kirim">
            </div>
          </div>
        </div>
      </div>
    </main>
  </body>
</form>
</html>
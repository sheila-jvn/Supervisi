<?php
// mengaktifkan session pada php
session_start();
 
// menghubungkan php dengan koneksi database
include '../koneksi/koneksi.php';

if(isset($_POST['simpan'])){
    $sql = "INSERT INTO guru VALUES ('$_POST[id_guru]', '$_POST[nama_guru]', '$_POST[jk]', '$_POST[alamat]', '$_POST[no_hp]', '$_POST[mapel]');";
    $eksekusi = mysqli_query($koneksi, $sql);
    echo "<script>alert('Berhasil tersimpan');document.location.href='?menu=inputGuru'</script>";
} 

if(isset($_GET['edit'])){
    $sql = mysqli_query($koneksi, "SELECT * FROM guru WHERE id_guru='$_GET[id]'");
    $isi = mysqli_fetch_array($sql);
}

if(isset($_GET['hapus'])){
    $sql = mysqli_query($koneksi, "DELETE FROM guru WHERE id_guru='$_GET[id]'");
}

if(isset($_POST['update'])){
    $sql = mysqli_query($koneksi, "UPDATE guru SET id_guru = '$_POST[id_guru]', nama_guru = '$_POST[nama_guru]', jk = '$_POST[jk]', alamat = '$_POST[alamat]', no_hp = '$_POST[no_hp]', mapel = '$_POST[mapel]' WHERE id_guru = '$_GET[id]'");
    if($sql){
        echo "<script>alert('Data berhasil diubah');document.location.href='?menu=inputGuru';</script>";
    }else{
        echo "<script>alert('Data gagal diubah');document.location.href='?menu=inputGuru';</script>";
    }
}

?>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Buat Jadwal</title>

    <link rel="stylesheet" href="../styles/style.css" />
    <link href="https://fonts.googleapis.com/css2?family=Source+Sans+Pro&display=swap" rel="stylesheet">
  </head>
  <form method="post" enctype="multipart/form-data" action="aksiupload.php">
  <body>
    <main class="container mt-2">
    <header class="container">
      <nav>
        <h4>Supervisi Digital</h4>
        <ul>
          <li><a href="dataGuru.php">Data Guru</a></li>
          <li><a href="#">Data Supervisor</a></li>
          <li><a href="#">Dokumen</a></li>
          <li><a href="../logout.php">logout</a></li>
        </ul>
      </nav>
    </header>
<div class="content">
        <br>
        <!-- Table -->
        <div class="table-responsive">
        <div>
          <div class="row">
              <label>ID Guru :</label>
            </div>

            <div>
              <input type="text" name="id_guru" class="full-width" value="<?php echo $isi['Id_guru'] ?>" required="required" />
            </div>

            <div>
          <div class="row">
              <label>Nama Guru :</label>
            </div>

            <div>
              <input type="text" name="nama_guru" class="full-width" value="<?php echo $isi['nama_guru'] ?>" required="required" />
            </div>

          <div>
          <div class="row">
              <label>Jenis Kelamin :</label>
            </div>

            <div>
              <input type="text" nama="jk" class="full-width" value="<?php echo $isi['jk'] ?>"required="required" />
            <div>
              <div class="row">
              <label>Alamat Rumah :</label>
            </div>

            <div>
              <input type="text" name="alamat" class="full-width" value="<?php echo $isi['alamat'] ?>" required="required" />

            <div>
              <div class="row">
              <label>Nomor Hp :</label>
            </div>

            <div>
              <input type="text" name="no_hp" class="full-width" value="<?php echo $isi['no_hp'] ?>"required="required" />

            <div>
              <div class="row">
              <label>Guru Mapel :</label>
            </div>

            <div>
              <input type="text" name="mapel" class="full-width" value="<?php echo $isi['mapel'] ?>"required="required" />
            
            </div>
            
            </form>
            <div>
                <table id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                      <th>Kode Guru</th>
                      <th>Nama Guru</th>
                      <th>Jenis Kelamin</th>
                      <th>Alamat Rumah</th>
                      <th>Nomor HP</th>
                      <th>Guru Mapel</th>
                      <th colspan="2">Aksi</th>
                    </tr>
                  </thead>
                  <tbody>
                      <?php
                        $sql = mysqli_query($koneksi, "SELECT * FROM guru");
                        while($r=mysqli_fetch_array($sql)){
                        ?>
                        <tr>
                            <td><?php echo $r['id_guru'] ?></td>
                            <td><?php echo $r['nama_guru'] ?></td>
                            <td><?php echo $r['jk'] ?></td>
                            <td><?php echo $r['alamat'] ?></td>
                            <td><?php echo $r['no_hp'] ?></td>
                            <td><?php echo $r['mapel'] ?></td>
                            <td><a class="btn btn-primary" href="?menu=inputGuru&edit&id=<?php echo $r['id_guru'] ?>">Edit</a></td>
                            <td><a class="btn btn-danger" href="?menu=inputGuru&hapus&id=<?php echo $r['id_guru'] ?>" onClick="return confirm('Anda Yakin?')">Hapus</a></td>
                        </tr>
                        <?php } ?>
                  </tbody>
                </table>
</html>
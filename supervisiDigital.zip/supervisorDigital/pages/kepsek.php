<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Supervisi Digital</title>

    <link rel="stylesheet" href="../styles/style.css" />
    <link href="https://fonts.googleapis.com/css2?family=Source+Sans+Pro&display=swap" rel="stylesheet">
  </head>
  <form method="post" enctype="multipart/form-data">
  <body>
    <header class="container">
      <nav>
        <h4>Supervisi Digital</h4>
        <ul>
          <li><a href="#">Laporan</a></li>
          <li><a href="../logout.php">logout</a></li>
        </ul>
      </nav>
    </header>

    <main class="container mt-2">

        <div class="eight columns">
          <div class="row">
            <div class="four columns">
              <label>Tanggal :</label>
            </div>

            <div class="eight columns">
              <input type="date" class="full-width" />
            </div>

            <div class="twelve columns">
              <label>Laporan :</label>
            </div>
          </div>
        </div>
      </div>
    </main>
  </body>
</form>
</html>

<?php 
// mengaktifkan session pada php
session_start();
 
// menghubungkan php dengan koneksi database
include '../koneksi/koneksi.php';
?>

<html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Buat Jadwal</title>

    <link rel="stylesheet" href="../styles/style.css" />
    <link href="https://fonts.googleapis.com/css2?family=Source+Sans+Pro&display=swap" rel="stylesheet">
  </head>
  <form method="post" enctype="multipart/form-data" action="aksiupload.php">
  <body>
    <main class="container mt-2">
    <header class="container">
      <nav>
        <h4>Supervisi Digital</h4>
        <ul>
          <li><a href="dataGuru.php">Data Guru</a></li>
          <li><a href="#">Data Supervisor</a></li>
          <li><a href="#">Dokumen</a></li>
          <li><a href="../logout.php">logout</a></li>
        </ul>
      </nav>
    </header>
<div class="content">
        <br>
        <!-- Table -->
        <div class="table-responsive">
        <div>
          <div class="row">
              <label>ID Guru :</label>
            </div>
          <div>
              <input type="text" class="full-width" />
            </div>

            <div>
          <div class="row">
              <label>Nama Guru :</label>
            </div>

            <div>
              <input type="text" class="full-width" />
            </div>

          <div>
          <div class="row">
              <label>Jenis Kelamin :</label>
            </div>

            <div>
              <input type="text" class="full-width" />
            <div>
              <div class="row">
              <label>Alamat Rumah :</label>
            </div>

            <div>
              <input type="text" class="full-width" />

            <div>
              <div class="row">
              <label>Nomor Hp :</label>
            </div>

            <div>
              <input type="text" class="full-width" />

            <div>
              <div class="row">
              <label>Guru Mapel :</label>
            </div>

            <div>
              <input type="text" class="full-width" />
            
            </div>
                <table width="100%" cellspacing="0">
                  <thead>
                    <tr>
                      <th>Kode Guru</th>
                      <th>Nama Guru</th>
                      <th>Jenis Kelamin</th>
                      <th>Alamat Rumah</th>
                      <th>Nomor HP</th>
                      <th>Guru Mapel</th>
                    </tr>
                  </thead>
                  <tbody>
                      <?php
                        $sql = mysqli_query($koneksi, "SELECT * FROM guru");
                        while($r=mysqli_fetch_array($sql)){
                        ?>
                        <tr>
                            <td><?php echo $r['id_guru'] ?></td>
                            <td><?php echo $r['nama_guru'] ?></td>
                            <td><?php echo $r['jk'] ?></td>
                            <td><?php echo $r['alamat'] ?></td>
                            <td><?php echo $r['no_hp'] ?></td>
                            <td><?php echo $r['mapel'] ?></td>
                        </tr>
                        <?php } ?>
                  </tbody>
                </table>
              </div>
        <!-- Akhir table -->
        </div>
<!-- akhir konten -->
</main>
</html>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Jadwal</title>

    <link rel="stylesheet" href="../styles/style.css" />
    <link href="https://fonts.googleapis.com/css2?family=Source+Sans+Pro&display=swap" rel="stylesheet">
  </head>
  <body>
    <header class="container">
      <nav>
        <h4>Supervisi Digital</h4>
        <ul>
          <li><a href="./upload.php">Upload</a></li>
          <li><a href="jadwal.php">Jadwal</a></li>
          <li><a href="../logout.php">logout</a></li>
        </ul>
      </nav>
    </header>

    <main class="container mt-2">
      <div class="row">
        <div class="four columns">
          <div class="row">
            <div class="twelve columns">
              <div class="menu-samping">Tanggal</div>
            </div>
          </div>
        </div>

        <div class="eight columns">
          <table>
            <thead>
              <tr>
                <th>No</th>
                <th>Nama Guru</th>
                <th>Mapel</th>
                <th>Dokumen</th>
              </tr>
            </thead>

            <tbody>
              <tr>
                <td>1</td>
                <td>Budiman</td>
                <td>Bhs. Jawa</td>
                <td><a href="#">Link</a></td>
              </tr>
              <tr>
                <td>2</td>
                <td>Budiman</td>
                <td>Bhs. Jawa</td>
                <td><a href="#">Link</a></td>
              </tr>
              <tr>
                <td>3</td>
                <td>Budiman</td>
                <td>Bhs. Jawa</td>
                <td><a href="#">Link</a></td>
              </tr>
              <tr>
                <td>4</td>
                <td>Budiman</td>
                <td>Bhs. Jawa</td>
                <td><a href="#">Link</a></td>
              </tr>
              <tr>
                <td>5</td>
                <td>Budiman</td>
                <td>Bhs. Jawa</td>
                <td><a href="#">Link</a></td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </main>
  </body>
</html>
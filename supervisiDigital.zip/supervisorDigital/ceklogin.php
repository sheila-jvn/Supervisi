<?php 
// mengaktifkan session pada php
session_start();
 
// menghubungkan php dengan koneksi database
include 'koneksi/koneksi.php';
 
// menangkap data yang dikirim dari form login
$username = $_POST['username'];
$password = $_POST['password'];
 
 
// menyeleksi data user dengan username dan password yang sesuai
$login = mysqli_query($koneksi,"select * from user where username='$username' and password='$password'");
// menghitung jumlah data yang ditemukan
$cek = mysqli_num_rows($login);
 
// cek apakah username dan password di temukan pada database
if($cek > 0){
 
	$data = mysqli_fetch_assoc($login);
 
	// cek jika user login sebagai pegawai
	if($data['level']=="guru"){
        $_SESSION['username'] = $username;
        $_SESSION['level'] = "guru";
        header("location:pages/upload.php");
 
	// cek jika user login sebagai kepsek
	}else if($data['level']=="kepsek"){
		// buat session login dan username
		$_SESSION['username'] = $username;
		$_SESSION['level'] = "kepsek";
		// alihkan ke halaman dashboard kepsek
		header("location:pages/kepsek.php");
 
	// cek jika user login sebagai kurikulum
	}else if($data['level']=="kurikulum"){
		// buat session login dan username
		$_SESSION['username'] = $username;
		$_SESSION['level'] = "kurikulum";
		// alihkan ke halaman dashboard kurikulum
		header("location:pages/kurikulum.php");

		// cek jika user login sebagai supervisor
	}else if($data['level']=="supervisor"){
		// buat session login dan username
		$_SESSION['username'] = $username;
		$_SESSION['level'] = "supervisor";
		// alihkan ke halaman dashboard supervisor
		header("location:pages/supervisor.php");
 
	}else{
 
		// alihkan ke halaman login kembali
		header("location:index.php?pesan=gagal");

}
 }
?>
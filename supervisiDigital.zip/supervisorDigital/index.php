<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <link rel="stylesheet" href="./styles/style.css" />

    <title>Supervisi Digital</title>
  </head>
  <body>
    <div class="centered-container full-screen-height">
      <form method="post" action="ceklogin.php">
        <h1>Login</h1>
        <input type="text" placeholder="Username" name="username" />
        <input type="password" placeholder="Password" name="password" />

        <button>Login</button>
      </form>
    </div>
  </body>
</html>
